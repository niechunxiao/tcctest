#' This function detects the significance of TCC between two single time series.
#'
#' @param s1 The first time series.
#' @param s2 The second time series.
#' @param k The vector k is used to generate the parameters of the kNN networks.
#' @param nrand The parameters used in the shuffling method.
#'
#' @return The output is a list of tcc value, z-value, and reference tcc values.
#' @export
#'
#' @examples tcc=seriestcc(tcctestdata[,1],tcctestdata[,2],c(1,299,1),100)
seriestcctest<-function(s1,s2,k,nrand){
  d1=as.matrix(dist(s1),method="euclidean")
  d2=as.matrix(dist(s2),method="euclidean")
  tcc=tdopolytest(d1, d2, k, nrand)
  return(tcc)
}
