#' This function calculates the nearest neighbor network from the sorted distance matrix.
#'
#' @param ds The sorted distance matrix.
#' @param k The parameter of the k-nearest neighbor network.
#'
#' @return The output of the function is an adjacency matrix.
#' @export
#'
#' @examples adj=directedknn(ds,3)
directedknn<-function(ds,k){
  #Directed kNN network.
  #The symbol d represents the distance matrix, and k is the parameter used to calculate the kNN network.
  n=dim(ds)
  n1=n[1]
  k1=k+1
  adj=matrix(data=0,nrow=n1,ncol = n1)
  for (i in 1:n1){
    adj[i,ds[i,c(1:k1)]]=1
  }

  for (i in 1:n1){
    adj[i,i]=0
  }
  return(adj)
}
