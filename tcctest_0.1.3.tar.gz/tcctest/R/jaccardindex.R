#' The function calculates the Jaccard similarity between networks.
#'
#' @param adj1 The adjacency matrix of the first network.
#' @param adj2 The adjacency matrix of the second network.
#'
#' @return Jaccard similarity
#' @export
#'
#' @examples t=jaccardindex(adj1,adj2)
jaccardindex<-function(adj1,adj2){
  #This is a function used to calculate the Jaccard similarity between networks.
  #The symbols adj1 and adj2 represent the adjacency matrices of the two networks.
  n1=sum(as.integer(adj1|adj2))
  adjprod=adj1*adj2
  n2=sum(adjprod)
  jaccard=n2/n1
  return(jaccard)
}
