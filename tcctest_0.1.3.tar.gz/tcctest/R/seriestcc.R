#' This function is used to calculate the TCC value between two single time series.
#'
#' @param s1 The first time series.
#' @param s2 The second time series.
#' @param k The vector k is used to generate the parameters of the kNN networks.
#'
#' @return The output is the tcc value.
#' @export
#'
#' @examples tcc=seriestcc(tcctestdata[,1],tcctestdata[,2],c(1,299,1))
seriestcc<-function(s1,s2,k){
  d1=as.matrix(dist(s1),method="euclidean")
  d2=as.matrix(dist(s2),method="euclidean")
  tcc=tdotcc(d1,d2,k)
  return(tcc)
}
