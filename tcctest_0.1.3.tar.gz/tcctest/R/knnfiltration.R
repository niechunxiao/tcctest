#' A function that implements undirected kNN filtering.
#'
#' @param d Distance matrix
#' @param k The vector k is used to set the parameters of the kNN network.
#'
#' @return A sequence of adjacency matrices for kNN networks.
#' @export
#'
#' @examples adj=knnfiltration(d,c(1,99,1))
knnfiltration<-function(d,k){
  #The vector k is used to set the parameters of the kNN network, where k[1] and k[2] represent the range of values of k, respectively,
  #and k[3] is used to set the interval of the parameters.
  n=dim(d)
  k1=as.matrix(seq(k[1],k[2],k[3])) #指定参数k的范围
  m=length(k1)#每个矩阵对应一个长度为m的kNN网络序列
  adj01 = array(0, dim = c(n[1],n[2],m))
  ds=t(apply(d,1,order))
  for (i in 1:m){
    adj01[,,i]=directedknn(ds,k1[i])
  }
  adj02 = array(0, dim = c(n[1],n[2],m))
  for (i in 1:m){
    adj02[,,i]=adj01[,,i]+t(adj01[,,i])
  }
  adj=array(0, dim = c(n[1],n[2],m))
  for (i in 1:m){
    adj[,,i]=ifelse(adj02[,,i]>0,1,0)
  }
  return(adj)
}
