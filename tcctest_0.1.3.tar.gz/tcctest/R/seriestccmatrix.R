#' This function calculates a TCC matrix between a set of time series.
#'
#' @param s A set of time series, where each column corresponds to a time series.
#' @param k The vector k is used to set the parameters of the kNN network, where k[1] and k[2] represent the range of values of k, respectively, and k[3] is used to set the interval of the parameters.
#'
#' @return TCC matrix
#' @export
#'
#' @examples tccm=seriestccmatrix(s,c(1,121,2))
seriestccmatrix<-function(s,k){
  n=dim(s)
  tccmat01=matrix(0,nrow = n[2],ncol = n[2])
  for (i in 1:n[2]) {
    for (j in 1:n[2]){
      if (i<j)tccmat01[i,j]= seriestcc(s[,i],s[,j],k)
    }
  }
  tccmat=tccmat01+t(tccmat01)
  diag(tccmat)=1
  return(tccmat)
}
