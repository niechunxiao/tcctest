#' This function generates surrogates by shuffling method.
#'
#' @param d Distance matrix
#'
#' @return The distance matrix after being processed by the shuffle.
#' @export
#'
#' @examples dshuf = tdoshuffle(d)
tdoshuffle<-function(d){
  #This function generates surrogates by shuffling.
  n=dim(d)
  L=sample(n[1])
  ds=d[L,L]
  return(ds)
}
