#' This function evaluates TCC based on a polynomial function.
#'
#' @param d1 The distance matrix of the first TDO.
#' @param d2 The distance matrix of the second TDO.
#' @param k The vector k is used to set the parameters of the kNN network, where k[1] and k[2] represent the range of values of k, respectively, and k[3] is used to set the interval of the parameters.
#'
#' @return TCC value
#' @export
#'
#' @examples d1=as.matrix(dist(henontdo[,c(1,2)]),method="euclidean")
#' @examples d2=as.matrix(dist(henontdo[,c(3,4)]),method="euclidean")
#' @examples tcc=tdopolytcc(d1,d2,c(1,999,6))
tdopolytcc<-function(d1,d2,k){
  #This function is used to calculate the generalized TCC between TDOs.
  #The vector k is used to set the parameters of the kNN network, where k[1] and k[2] represent the range of values of k, respectively,
  #and k[3] is used to set the interval of the parameters.
  n=dim(d1)
  k1=as.matrix(seq(k[1],k[2],k[3])) #指定参数k的范围
  m=length(k1)#每个矩阵对应一个长度为m的kNN网络序列
  t1 = array(0, dim = c(n[1],n[2],m))
  t2 = array(0, dim = c(n[1],n[2],m))
  ds1=t(apply(d1,1,order))
  ds2=t(apply(d2,1,order))
  for (i in 1:m){
    t1[,,i]=directedknn(ds1,k1[i])
    t2[,,i]=directedknn(ds2,k1[i])
  }
  jaccard=matrix(data=0,nrow = m,ncol = 1)
  for (i in 1:m){
    jaccard[i]=jaccardindex(t1[,,i],t2[,,i])
  }
  s=k1/n[1]
  cs=lm(jaccard~s+I(s^2)+I(s^3))
  coe=cs$coefficients
  f=function(x)(coe[1]+coe[2]*x+coe[3]*x^2+coe[4]*x^3)
  IJ=integrate(f,0,1)
  tcc=IJ$value
  return(tcc)
}
